# Restaurant POS implementation status

## Implemented in this ZIP
- Express API bootstrap and PostgreSQL connection pool.
- Password hashing with Node.js scrypt and constant-time password verification.
- Signed HS256 access tokens with expiry checks.
- Login and current-user endpoints.
- Master Admin API to list restaurants and create a restaurant plus its first Restaurant Admin in one database transaction.
- Tenant context is derived from signed token claims; client-supplied restaurant headers are ignored.
- PostgreSQL schema constraints prevent master users from being assigned to a restaurant and enforce same-restaurant table/area/category relationships.
- Unit tests for password hashing, token validation, tenant isolation and order calculations/ticket routing.

## Not implemented yet (do not treat as production-complete)
- Restaurant Admin CRUD screens and full business APIs.
- Waiter Android app, kitchen/bar displays, printer agent and physical ESC/POS integration.
- Payments, tax configuration, discounts, refunds, split/merged bills, audit logs.
- Durable offline queue, conflict resolution and sync protocol.
- Full row-level security policies, refresh/revocation flow, rate limiting, MFA, security audit and deployment automation.
- End-to-end tests against a real PostgreSQL instance and physical printer models.

## Install and run API
1. Install Node.js 20+ and PostgreSQL 15+.
2. `cd server && npm install`
3. Copy `.env.example` to `.env`; set DATABASE_URL and a cryptographically random JWT_SECRET of at least 32 bytes.
4. From project root apply schema: `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/schema.sql`
5. Create the first master admin: `cd server && npm run seed:master -- admin@example.com "use-a-long-unique-password"`
6. Start: `npm start`
7. Test: `npm test`

The schema file is for a fresh database. Do not run it over an existing production database without a reviewed migration and backup.


## Delivery status (updated)
- [x] Authentication foundation and password hashing
- [x] Master Admin: create/list/detail/enable-disable restaurant tenants
- [x] Restaurant Admin: dashboard, service areas, tables, menu categories and menu items
- [x] Role-protected API routes and token-derived tenant scoping
- [x] Unit tests for order domain, password handling, token verification and tenant context
- [ ] Full waiter Android app
- [ ] Kitchen/bar ticket workflow and ESC/POS print agent
- [ ] Billing, payment, refunds, shifts and accounting
- [ ] Offline-first storage and conflict-safe synchronization
- [ ] Production deployment, monitoring, backup restore drills and external security review
