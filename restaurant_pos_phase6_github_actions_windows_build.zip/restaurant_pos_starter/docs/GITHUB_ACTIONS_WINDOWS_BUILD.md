## Build the Windows installer with GitHub Actions

This repository includes `.github/workflows/windows-build.yml`. GitHub Actions builds the Windows installer on a hosted Windows runner, so npm does not need to be installed on your own PC for the packaging step.

### One-time GitHub setup

1. Extract this ZIP on your computer.
2. Open the `restaurant_pos_starter` folder.
3. Create a new empty GitHub repository (for example `restaurant-pos`).
4. Upload the **contents** of `restaurant_pos_starter` to the repository root. Make sure `.github/workflows/windows-build.yml` is included. GitHub's web upload may hide dot-folders; if so, use GitHub Desktop or the Git command line to commit the `.github` folder.
5. In GitHub, open **Actions** and select **Build Restaurant POS Windows Installer**.
6. Choose **Run workflow** (or push a commit to `main` after enabling Actions).
7. Wait for the job to finish. A green check means the workflow completed.
8. Open the completed workflow run, scroll to **Artifacts**, and download `Restaurant-POS-Windows-Installer`. Extract it to get `Restaurant-POS-Admin-Setup-0.2.0.exe`.

### Notes

- The workflow uses a hosted Windows runner and uploads the installer as a temporary GitHub Actions artifact (14-day retention).
- The installer is not automatically published as a GitHub Release.
- This workflow builds the current Electron admin app only. It does not deploy the API/database or make the unfinished POS features production-ready.
- Do not commit passwords, API secrets, database credentials, `.env` files, or signing certificates.
- The first build downloads Electron and packaging dependencies and may take several minutes.