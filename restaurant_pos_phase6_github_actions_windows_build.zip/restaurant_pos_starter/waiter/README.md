# Waiter App (Expo starter)

This directory reserves the mobile app workspace. Initialize with:

```bash
npx create-expo-app@latest .
```

Recommended first screens:
- Staff sign-in
- Select service area and table
- Browse menu and modifiers
- Current order / send to kitchen
- Order status and table transfer

Offline storage and sync are not implemented in this starter.
