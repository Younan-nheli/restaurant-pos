const { app, BrowserWindow, shell, ipcMain } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

let mainWindow;

const SETTINGS_FILE = () => path.join(app.getPath('userData'), 'pos-desktop-settings.json');
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function isTrustedSender(event) {
  return mainWindow && event.sender === mainWindow.webContents &&
    event.senderFrame === mainWindow.webContents.mainFrame;
}
async function readSettings() {
  try {
    const parsed = JSON.parse(await fs.readFile(SETTINGS_FILE(), 'utf8'));
    return {
      kitchenPrinter: typeof parsed.kitchenPrinter === 'string' ? parsed.kitchenPrinter : '',
      barPrinter: typeof parsed.barPrinter === 'string' ? parsed.barPrinter : '',
      receiptPrinter: typeof parsed.receiptPrinter === 'string' ? parsed.receiptPrinter : ''
    };
  } catch { return { kitchenPrinter: '', barPrinter: '', receiptPrinter: '' }; }
}
function registerDesktopIpc() {
  ipcMain.handle('pos:list-printers', async event => {
    if (!isTrustedSender(event)) throw new Error('Untrusted desktop sender');
    return (await event.sender.getPrintersAsync()).map(p => ({
      name: p.name, displayName: p.displayName, isDefault: p.isDefault,
      status: p.status
    }));
  });
  ipcMain.handle('pos:get-printer-settings', async event => {
    if (!isTrustedSender(event)) throw new Error('Untrusted desktop sender');
    return readSettings();
  });
  ipcMain.handle('pos:save-printer-settings', async (event, value) => {
    if (!isTrustedSender(event)) throw new Error('Untrusted desktop sender');
    const keys = ['kitchenPrinter', 'barPrinter', 'receiptPrinter'];
    if (!value || typeof value !== 'object' || keys.some(k => typeof value[k] !== 'string' || value[k].length > 256))
      throw new Error('Invalid printer settings');
    await fs.mkdir(app.getPath('userData'), { recursive: true });
    await fs.writeFile(SETTINGS_FILE(), JSON.stringify(Object.fromEntries(keys.map(k => [k, value[k]])), null, 2), { mode: 0o600 });
    return { saved: true };
  });
  ipcMain.handle('pos:print-text', async (event, payload) => {
    if (!isTrustedSender(event)) throw new Error('Untrusted desktop sender');
    if (!payload || typeof payload.text !== 'string' || payload.text.length > 12000)
      throw new Error('Invalid print content');
    const printer = typeof payload.printer === 'string' ? payload.printer.slice(0, 256) : '';
    const title = escapeHtml(typeof payload.title === 'string' ? payload.title.slice(0, 80) : 'Restaurant POS');
    const content = escapeHtml(payload.text);
    const printWindow = new BrowserWindow({
      show: false, width: 420, height: 800,
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
    });
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
      <style>@page{margin:4mm}body{font:12px Consolas,monospace;white-space:pre-wrap;width:72mm;margin:0;color:#000}</style>
      </head><body>${content}</body></html>`;
    try {
      await printWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
      return await new Promise((resolve, reject) => {
        printWindow.webContents.print({
          silent: Boolean(printer), printBackground: true,
          ...(printer ? { deviceName: printer } : {})
        }, (success, failureReason) => {
          printWindow.close();
          if (success) resolve({ printed: true });
          else reject(new Error(failureReason || 'Print failed'));
        });
      });
    } catch (error) {
      if (!printWindow.isDestroyed()) printWindow.close();
      throw error;
    }
  });
}


function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#f4f6f8',
    title: 'Restaurant POS — Admin',
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    const localUrl = pathToFileURL(path.join(__dirname, 'dist', 'index.html')).href;
    if (url !== localUrl && !url.startsWith('file://')) event.preventDefault();
  });

  mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
  app.whenReady().then(() => {
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
