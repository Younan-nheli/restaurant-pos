# Restaurant POS Admin for Windows

## Windows desktop shell

This package wraps the React administration interface in Electron. The desktop window uses context isolation, disabled Node integration, a sandboxed preload bridge, single-instance locking and external-link handling.

## Build a Windows installer

On a Windows 10/11 x64 computer with Node.js 20+ and npm:

```powershell
cd admin
npm install
npm run desktop:dist:win
```

The NSIS installer is written to `admin/release/`. A portable build can be created with `npm run desktop:dist:portable`.

## Run during development

```powershell
cd admin
npm install
npm run desktop:dev
```

## Windows printer setup

When running as the Electron desktop app and signed in as a Restaurant Admin, the Printer setup panel:
- Lists printers installed in Windows.
- Stores separate printer assignments for kitchen tickets, bar tickets and customer receipts in the current Windows user's Electron application data folder.
- Sends a test page to the selected printer using the Windows/Electron print pipeline.

Printer assignments are local to each Windows computer. Install the printer's Windows driver first. The print test confirms that Windows accepted a print job; it does not prove that a complete order ticket or receipt layout is correct.

## Important limitations

- This archive contains source code and installer configuration, not a prebuilt `.exe`.
- A Windows installer has not been built or tested on a Windows machine in this environment.
- The printer bridge is a basic Windows print pipeline. Direct raw ESC/POS command support, cash-drawer control, cutter control, barcode/QR formatting and printer status monitoring are not implemented yet.
- Kitchen/bar routing exists in the menu/order domain foundation, but end-to-end order creation, ticket dispatch, retries and duplicate-print protection still need implementation and hardware testing.
- The API/database are not installed or managed as Windows services.
- Offline transaction queue and secure synchronization are not implemented.
- Waiter Android app, billing, split bills and table transfer/merge are not complete.

Do not use this build for live restaurant transactions until API integration, Windows packaging, printer hardware, security, offline recovery and end-to-end workflows have been tested.
