const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('restaurantPOS', Object.freeze({
  appName: 'Restaurant POS Admin',
  platform: process.platform,
  desktop: true,
  listPrinters: () => ipcRenderer.invoke('pos:list-printers'),
  getPrinterSettings: () => ipcRenderer.invoke('pos:get-printer-settings'),
  savePrinterSettings: settings => ipcRenderer.invoke('pos:save-printer-settings', settings),
  printText: payload => ipcRenderer.invoke('pos:print-text', payload)
}));
