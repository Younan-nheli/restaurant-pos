-- Fresh-install PostgreSQL schema for the POS API foundation.
-- Apply with: psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/schema.sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL CHECK (length(trim(name)) > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE restaurants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  name TEXT NOT NULL CHECK (length(trim(name)) > 0),
  timezone TEXT NOT NULL DEFAULT 'Asia/Baghdad',
  currency CHAR(3) NOT NULL DEFAULT 'IQD',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE app_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID REFERENCES restaurants(id) ON DELETE RESTRICT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('master_admin','restaurant_admin','waiter','cashier','kitchen')),
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (id, restaurant_id),
  CONSTRAINT user_tenant_role_check CHECK (
    (role = 'master_admin' AND restaurant_id IS NULL) OR
    (role <> 'master_admin' AND restaurant_id IS NOT NULL)
  )
);
CREATE INDEX app_users_restaurant_idx ON app_users(restaurant_id);
CREATE TABLE service_areas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  name TEXT NOT NULL CHECK (length(trim(name)) > 0),
  UNIQUE (restaurant_id, name),
  UNIQUE (id, restaurant_id)
);
CREATE TABLE dining_tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  service_area_id UUID NOT NULL,
  table_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','occupied','reserved','disabled')),
  UNIQUE (restaurant_id, table_name),
  FOREIGN KEY (service_area_id, restaurant_id) REFERENCES service_areas(id, restaurant_id) ON DELETE CASCADE
);
CREATE TABLE menu_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE (id, restaurant_id)
);
CREATE TABLE menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  category_id UUID,
  name TEXT NOT NULL,
  price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
  routing_group TEXT NOT NULL DEFAULT 'kitchen' CHECK (routing_group IN ('kitchen','bar','other')),
  active BOOLEAN NOT NULL DEFAULT true,
  FOREIGN KEY (category_id, restaurant_id) REFERENCES menu_categories(id, restaurant_id) ON DELETE RESTRICT
);
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE RESTRICT,
  table_id UUID,
  waiter_id UUID,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','sent','preparing','ready','served','paid','void')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (id, restaurant_id),
  FOREIGN KEY (table_id, restaurant_id) REFERENCES dining_tables(id, restaurant_id) ON DELETE RESTRICT,
  FOREIGN KEY (waiter_id, restaurant_id) REFERENCES app_users(id, restaurant_id) ON DELETE RESTRICT
);
CREATE INDEX orders_restaurant_created_idx ON orders(restaurant_id, created_at DESC);
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE RESTRICT,
  order_id UUID NOT NULL,
  menu_item_id UUID NOT NULL,
  quantity NUMERIC(10,2) NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  FOREIGN KEY (order_id, restaurant_id) REFERENCES orders(id, restaurant_id) ON DELETE CASCADE,
  FOREIGN KEY (menu_item_id, restaurant_id) REFERENCES menu_items(id, restaurant_id) ON DELETE RESTRICT
);
