import test from 'node:test';
import assert from 'node:assert/strict';
import { buildOrderDraft } from '../src/domain/orders.js';

const sample = {
  restaurantId: 'restaurant-a',
  tableId: 'table-4',
  waiterId: 'waiter-2',
  items: [
    { menuItemId: 'meal-1', name: 'Grilled chicken', quantity: 2, unitPriceMinor: 7500, routingGroup: 'kitchen' },
    { menuItemId: 'drink-1', name: 'Orange juice', quantity: 1, unitPriceMinor: 2000, routingGroup: 'bar' },
    { menuItemId: 'meal-2', name: 'Soup', quantity: 1, unitPriceMinor: 1500, routingGroup: 'kitchen', notes: 'No salt' }
  ]
};

test('calculates the order subtotal using integer arithmetic', () => {
  const order = buildOrderDraft(sample);
  assert.equal(order.subtotalMinor, 18500);
  assert.equal(order.items[0].lineTotalMinor, 15000);
  assert.equal(order.currency, 'IQD');
});

test('routes food and drinks into separate preparation tickets', () => {
  const order = buildOrderDraft(sample);
  assert.deepEqual(order.tickets.map(ticket => ticket.routingGroup), ['kitchen', 'bar']);
  assert.deepEqual(order.tickets[0].items.map(item => item.name), ['Grilled chicken', 'Soup']);
  assert.deepEqual(order.tickets[1].items.map(item => item.name), ['Orange juice']);
  assert.equal(order.tickets[0].subtotalMinor + order.tickets[1].subtotalMinor, order.subtotalMinor);
});

test('rejects empty orders and invalid quantities', () => {
  assert.throws(() => buildOrderDraft({ ...sample, items: [] }), /at least one item/);
  assert.throws(() => buildOrderDraft({ ...sample, items: [{ ...sample.items[0], quantity: 0 }] }), /positive integer/);
});

test('rejects unsupported printer routing groups', () => {
  assert.throws(() => buildOrderDraft({ ...sample, items: [{ ...sample.items[0], routingGroup: 'cashier' }] }), /routingGroup is invalid/);
});

test('rejects unsafe integer totals', () => {
  assert.throws(() => buildOrderDraft({
    ...sample,
    items: [{ ...sample.items[0], quantity: 2, unitPriceMinor: Number.MAX_SAFE_INTEGER }]
  }), /total is too large/);
});
