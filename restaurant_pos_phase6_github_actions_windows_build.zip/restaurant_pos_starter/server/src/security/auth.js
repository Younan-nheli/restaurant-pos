export const ROLES = Object.freeze(['master_admin','restaurant_admin','waiter','cashier','kitchen']);

export function isValidIdentity(user) {
  return Boolean(user && typeof user.id === 'string' && ROLES.includes(user.role) &&
    (user.role === 'master_admin' ? user.restaurant_id === null : typeof user.restaurant_id === 'string'));
}

export function canAccessRestaurant(user, restaurantId) {
  if (!user || typeof restaurantId !== 'string' || !restaurantId) return false;
  return user.role === 'master_admin' || user.restaurant_id === restaurantId;
}

export function requireRole(user, allowedRoles) {
  return Boolean(user && Array.isArray(allowedRoles) && allowedRoles.includes(user.role));
}
