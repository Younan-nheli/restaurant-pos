import { verifyAccessToken } from '../security/tokens.js';

export function authenticationRequired(req, res, next) {
  const header = req.get('authorization') || '';
  const match = /^Bearer ([A-Za-z0-9._~-]+)$/.exec(header);
  if (!match) return res.status(401).json({ error: 'authentication_required' });
  const claims = verifyAccessToken(match[1], process.env.JWT_SECRET);
  if (!claims) return res.status(401).json({ error: 'invalid_or_expired_token' });
  req.auth = { userId: claims.sub, role: claims.role, restaurantId: claims.restaurantId ?? null };
  return next();
}

export function requireRoles(...roles) {
  return (req, res, next) => roles.includes(req.auth?.role)
    ? next()
    : res.status(403).json({ error: 'forbidden' });
}

export function tenantContext(req, res, next) {
  // Tenant IDs come only from signed claims. Client-supplied x-restaurant-id is ignored.
  if (req.auth?.role === 'master_admin') req.tenant = { restaurantId: null, isPlatformAdmin: true };
  else req.tenant = { restaurantId: req.auth?.restaurantId ?? null, isPlatformAdmin: false };
  if (req.auth && !req.tenant.isPlatformAdmin && !req.tenant.restaurantId) {
    return res.status(403).json({ error: 'restaurant_context_required' });
  }
  return next();
}
