const ROUTING_GROUPS = new Set(['kitchen', 'bar', 'other']);

/**
 * Build a validated immutable order draft and deterministic preparation tickets.
 * Prices are integer minor units (for IQD deployments, normally whole dinars).
 * This module has no database or network side effects.
 */
export function buildOrderDraft({ restaurantId, tableId = null, waiterId, items }) {
  if (!isNonEmptyString(restaurantId)) throw new TypeError('restaurantId is required');
  if (!isNonEmptyString(waiterId)) throw new TypeError('waiterId is required');
  if (tableId !== null && !isNonEmptyString(tableId)) throw new TypeError('tableId must be a string or null');
  if (!Array.isArray(items) || items.length === 0) throw new TypeError('Order must contain at least one item');

  const normalizedItems = items.map((item, index) => {
    if (!item || typeof item !== 'object') throw new TypeError(`items[${index}] must be an object`);
    if (!isNonEmptyString(item.menuItemId)) throw new TypeError(`items[${index}].menuItemId is required`);
    if (!isNonEmptyString(item.name)) throw new TypeError(`items[${index}].name is required`);
    if (!Number.isSafeInteger(item.quantity) || item.quantity <= 0) {
      throw new TypeError(`items[${index}].quantity must be a positive integer`);
    }
    if (!Number.isSafeInteger(item.unitPriceMinor) || item.unitPriceMinor < 0) {
      throw new TypeError(`items[${index}].unitPriceMinor must be a non-negative safe integer`);
    }
    const routingGroup = item.routingGroup ?? 'kitchen';
    if (!ROUTING_GROUPS.has(routingGroup)) throw new TypeError(`items[${index}].routingGroup is invalid`);
    const lineTotalMinor = item.quantity * item.unitPriceMinor;
    if (!Number.isSafeInteger(lineTotalMinor)) throw new RangeError(`items[${index}] total is too large`);
    return Object.freeze({
      menuItemId: item.menuItemId,
      name: item.name,
      quantity: item.quantity,
      unitPriceMinor: item.unitPriceMinor,
      lineTotalMinor,
      routingGroup,
      notes: typeof item.notes === 'string' ? item.notes.trim() : ''
    });
  });

  const subtotalMinor = normalizedItems.reduce((sum, item) => {
    const next = sum + item.lineTotalMinor;
    if (!Number.isSafeInteger(next)) throw new RangeError('Order subtotal is too large');
    return next;
  }, 0);

  const ticketsByGroup = new Map();
  for (const item of normalizedItems) {
    if (!ticketsByGroup.has(item.routingGroup)) ticketsByGroup.set(item.routingGroup, []);
    ticketsByGroup.get(item.routingGroup).push(item);
  }

  const tickets = [...ticketsByGroup.entries()].map(([routingGroup, ticketItems]) => Object.freeze({
    routingGroup,
    items: Object.freeze(ticketItems),
    subtotalMinor: ticketItems.reduce((sum, item) => sum + item.lineTotalMinor, 0)
  }));

  return Object.freeze({
    restaurantId,
    tableId,
    waiterId,
    items: Object.freeze(normalizedItems),
    subtotalMinor,
    currency: 'IQD',
    tickets: Object.freeze(tickets)
  });
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}
