# Restaurant POS – Development Package

This ZIP contains a working **backend foundation**, not a finished commercial POS. Implemented features are listed in `docs/IMPLEMENTATION_PLAN.md`.

## Current backend capabilities
- PostgreSQL-backed login with scrypt password hashes
- Signed access tokens and role checks
- Master Admin can create restaurants and their first Restaurant Admin transactionally
- Tenant context comes from signed authentication claims, not client-supplied tenant headers
- Order draft calculation and food/bar ticket grouping

## Quick start
See `docs/IMPLEMENTATION_PLAN.md` for full setup. The API requires PostgreSQL and npm dependencies.

## Verification
Run `cd server && npm test`. Tests use Node's built-in test runner and do not require a database. API integration tests require a configured PostgreSQL database.

## Production warning
No software can honestly be guaranteed “without any errors”. This version has automated unit tests, but it has not yet undergone end-to-end, penetration, load, printer-hardware or offline-recovery testing. Do not use it for live restaurant transactions until those stages are completed.


## Phase 3 update
Master Admin restaurant provisioning and tenant activation controls are implemented. Restaurant Admin endpoints now manage dashboard summaries, service areas, tables, menu categories and menu items. The React admin web app supports sign-in and these management workflows. See `docs/PHASE_3_MASTER_RESTAURANT_ADMIN.md`.

This remains an in-progress POS platform, not a fully production-certified system. See the verification boundaries in the phase document.

## Windows desktop application (Phase 4 foundation)
The `admin/` folder now includes an Electron desktop shell for the existing React administration UI. See `admin/WINDOWS_APP.md` for Windows installer build instructions and current limitations. This is desktop packaging source, not a prebuilt `.exe` installer.

## Windows desktop and printer foundation (Phase 5)

The Electron desktop app now exposes a narrow, validated preload bridge for listing Windows printers, saving per-PC kitchen/bar/receipt printer assignments, and sending test print jobs. Restaurant Admin sees a printer setup panel only in the desktop build. This is not yet raw ESC/POS support or end-to-end ticket printing; see `admin/WINDOWS_APP.md`.

See `docs/PHASE_5_WINDOWS_PRINTERS.md` for the Windows printer foundation and verification limits.

## Build the Windows installer with GitHub Actions

This repository includes `.github/workflows/windows-build.yml`. GitHub Actions builds the Windows installer on a hosted Windows runner, so npm does not need to be installed on your own PC for the packaging step.

### One-time GitHub setup

1. Extract this ZIP on your computer.
2. Open the `restaurant_pos_starter` folder.
3. Create a new empty GitHub repository (for example `restaurant-pos`).
4. Upload the **contents** of `restaurant_pos_starter` to the repository root. Make sure `.github/workflows/windows-build.yml` is included. GitHub's web upload may hide dot-folders; if so, use GitHub Desktop or the Git command line to commit the `.github` folder.
5. In GitHub, open **Actions** and select **Build Restaurant POS Windows Installer**.
6. Choose **Run workflow** (or push a commit to `main` after enabling Actions).
7. Wait for the job to finish. A green check means the workflow completed.
8. Open the completed workflow run, scroll to **Artifacts**, and download `Restaurant-POS-Windows-Installer`. Extract it to get `Restaurant-POS-Admin-Setup-0.2.0.exe`.

### Notes

- The workflow uses a hosted Windows runner and uploads the installer as a temporary GitHub Actions artifact (14-day retention).
- The installer is not automatically published as a GitHub Release.
- This workflow builds the current Electron admin app only. It does not deploy the API/database or make the unfinished POS features production-ready.
- Do not commit passwords, API secrets, database credentials, `.env` files, or signing certificates.
- The first build downloads Electron and packaging dependencies and may take several minutes.
